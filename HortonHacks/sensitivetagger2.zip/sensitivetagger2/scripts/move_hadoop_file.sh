hadoop fs -mv $1 $2
